import React from 'react';
import WhiteBoard from "./WhiteBoard";

function App() {
  return (
      <WhiteBoard/>
  );
}

export default App;
